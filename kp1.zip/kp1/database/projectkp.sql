-- phpMyAdmin SQL Dump
-- version 4.8.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 19 Feb 2020 pada 08.24
-- Versi server: 10.1.32-MariaDB
-- Versi PHP: 5.6.36

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `projectkp`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `address_table`
--

CREATE TABLE `address_table` (
  `address_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `country` varchar(50) NOT NULL,
  `postcode` varchar(10) NOT NULL,
  `address` varchar(100) NOT NULL,
  `town` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `address_table`
--

INSERT INTO `address_table` (`address_id`, `user_id`, `country`, `postcode`, `address`, `town`) VALUES
(9, 2, 'Sby', 'BE3119', 'No 48', 'BSB'),
(10, 3, 'BSB', 'BSB', 'BSB', 'BSB');

-- --------------------------------------------------------

--
-- Struktur dari tabel `cart_table`
--

CREATE TABLE `cart_table` (
  `cart_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `date_buy` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `flag` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `cart_table`
--

INSERT INTO `cart_table` (`cart_id`, `user_id`, `date_buy`, `flag`) VALUES
(12, 2, '2017-10-30 09:12:01', 1),
(13, 2, '2017-10-31 10:24:58', 1),
(14, 3, '2017-10-31 10:29:49', 1),
(15, 2, '2020-02-05 18:47:53', 1),
(16, 2, '2020-02-13 19:05:38', 1),
(17, 2, '2020-02-19 14:17:34', 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `category_table`
--

CREATE TABLE `category_table` (
  `category_id` int(11) NOT NULL,
  `category_name` varchar(50) NOT NULL,
  `parent_category_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `category_table`
--

INSERT INTO `category_table` (`category_id`, `category_name`, `parent_category_id`) VALUES
(19, 'LAHAN 3', 0),
(20, 'LAHAN 4', 0),
(21, 'LAHAN 2', 0),
(22, 'LAHAN 5', 0),
(23, 'LAHAN 1', 0),
(25, 'Pohon 101', 23),
(26, 'Pohon 102', 23),
(27, 'Pohon 100', 23),
(28, 'Pohon 301', 19),
(29, 'Pohon 302', 19),
(30, 'Pohon 304', 19),
(32, 'Pohon 402', 20),
(33, 'Pohon 401', 20),
(34, 'Pohon 203', 21),
(35, 'Pohon 200', 21),
(36, 'Pohon 202', 21),
(37, 'Pohon 201', 21),
(38, 'Pohon 501', 22),
(39, 'Pohon 500', 22),
(40, 'Pohon 502', 22),
(41, 'Pohon 303', 19);

-- --------------------------------------------------------

--
-- Struktur dari tabel `contact_table`
--

CREATE TABLE `contact_table` (
  `message_id` int(11) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `message` text NOT NULL,
  `submit_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `flag` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `contact_table`
--

INSERT INTO `contact_table` (`message_id`, `full_name`, `email`, `message`, `submit_time`, `flag`) VALUES
(5, 'Putri', 'putrimilfi@gmail.com', 'Lahan 1 dalam keadaan baik. Good!', '2020-02-10 20:13:22', 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `perkemb_images`
--

CREATE TABLE `perkemb_images` (
  `perkemb_images_id` int(11) NOT NULL,
  `perkemb_id` int(11) NOT NULL,
  `image_link` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `perkemb_images`
--

INSERT INTO `perkemb_images` (`perkemb_images_id`, `perkemb_id`, `image_link`) VALUES
(1, 0, 'uploads/tanggal_171.jpg'),
(2, 2, 'uploads/IMG_20200113_154626.jpg'),
(3, 3, 'uploads/tgl28jan.jpg'),
(4, 1, 'uploads/tgl7feb.jpg'),
(5, 4, 'uploads/tgl3feb.jpg');

-- --------------------------------------------------------

--
-- Struktur dari tabel `perkemb_table`
--

CREATE TABLE `perkemb_table` (
  `perkemb_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `product_name` varchar(100) NOT NULL,
  `description` text NOT NULL,
  `add_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `activeflag` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `perkemb_table`
--

INSERT INTO `perkemb_table` (`perkemb_id`, `product_id`, `category_id`, `product_name`, `description`, `add_time`, `activeflag`) VALUES
(1, 2, 28, 'Pohon 3012', '<p>ccbvcvbmnnmnnmbm&nbsp;</p>\r\n', '2020-02-14 12:50:57', 0),
(2, 0, 25, 'Pohon 1010', '<p>sjdhfuh sahdjhreu adserhja sdsadeisjdhfuh sahdjhreu adserhja sdsadei</p>\r\n', '0000-00-00 00:00:00', 0),
(3, 0, 28, 'Pohon 3011', '<p>public function manage_category($category_id) {<br />\r\n&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;$this-&gt;gate_model-&gt;admin_gate();<br />\r\n&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;$data[&quot;category&quot;] = $this-&gt;category_model-&gt;getCategoryData($category_id);<br />\r\n&nbsp; &nbsp; &nbsp;</p>\r\n', '0000-00-00 00:00:00', 0),
(4, 0, 25, 'Pohon 1012', '<p>kjfdkjfd session-&gt;flashdata(&quot;msg&quot;); ?</p>\r\n\r\n<p>&nbsp;</p>\r\n', '2020-02-14 13:02:20', 0);

-- --------------------------------------------------------

--
-- Struktur dari tabel `product_cart_table`
--

CREATE TABLE `product_cart_table` (
  `product_cart_id` int(11) NOT NULL,
  `cart_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `add_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `product_cart_table`
--

INSERT INTO `product_cart_table` (`product_cart_id`, `cart_id`, `product_id`, `quantity`, `add_time`) VALUES
(1, 17, 41, 1, '2020-02-19 07:17:18');

-- --------------------------------------------------------

--
-- Struktur dari tabel `product_images`
--

CREATE TABLE `product_images` (
  `product_images_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `image_link` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `product_images`
--

INSERT INTO `product_images` (`product_images_id`, `product_id`, `image_link`) VALUES
(40, 40, 'uploads/10001.jpg'),
(41, 41, 'uploads/1001.jpg'),
(42, 42, 'uploads/1002.jpg');

-- --------------------------------------------------------

--
-- Struktur dari tabel `product_table`
--

CREATE TABLE `product_table` (
  `product_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `seller_id` int(11) NOT NULL,
  `product_name` varchar(100) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `short_desc` varchar(50) NOT NULL,
  `description` text NOT NULL,
  `add_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `active_flag` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `product_table`
--

INSERT INTO `product_table` (`product_id`, `category_id`, `seller_id`, `product_name`, `price`, `short_desc`, `description`, `add_time`, `active_flag`) VALUES
(40, 27, 7, 'Pohon 1000', '75.00', 'Lahan 1 Pohon 1000', '<p>jdsdkskds</p>\r\n', '2020-02-18 11:42:29', 0),
(41, 27, 7, 'Pohon 1001', '75.00', 'Lahan 1 Pohon 1001', '<p>mflkdjfdsjd</p>\r\n', '2020-02-18 11:43:23', 0),
(42, 27, 7, 'Pohon 1002', '75.00', 'Lahan 1 Pohon 1002', '<p>dlsmdslmd</p>\r\n', '2020-02-18 11:44:31', 0);

-- --------------------------------------------------------

--
-- Struktur dari tabel `review_table`
--

CREATE TABLE `review_table` (
  `review_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `review` varchar(100) NOT NULL,
  `post_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `user_table`
--

CREATE TABLE `user_table` (
  `user_id` int(11) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `company_name` varchar(30) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(30) NOT NULL,
  `password` varchar(255) NOT NULL,
  `user_type` varchar(30) NOT NULL DEFAULT 'buyer',
  `ban_flag` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `user_table`
--

INSERT INTO `user_table` (`user_id`, `first_name`, `last_name`, `company_name`, `username`, `email`, `password`, `user_type`, `ban_flag`) VALUES
(1, 'Admin', 'Admin', '', 'admin', 'admin@admin.com', '$2y$10$2fsiOiSV9GmPDfBLbo5D7eanESB3cFNLXk0MEAADhkhmv2IQwGZUy', 'admin', 0),
(2, 'Putri', 'Fitri', '', 'putri', 'putrimilfi@gmail.com', '$2y$10$HDhpPaXA3vEuWw3Ia.3/gO.3v60XLy/us1PYP5YfkZq76rUzevTLO', 'user', 0),
(3, 'Amirul', 'Ariffin', '', 'amirul', 'amirul@admin.com', '$2y$10$TmX.vE46l.FiGyLFG7j8PuBun4d14VcqUtHydClrGlm1pRZOEFTie', 'user', 0),
(5, 'Putri', 'Fitri', '', 'puttttt', 'putrimf@gmail.com', '$2y$10$4c8JT1Kt4H/nAJOTdUIq9.iiEX7AamEKgGdmLacYGaTwas9Oe7reK', 'user', 1),
(7, 'Putri', 'Fitri', 'xxx', 'adminput', 'putrii@admin.com', '$2y$10$6azs9AKaz.TBLUlz9eDITOj/hjZK9g5VV5gtIAKxKMWVNH3sMy3NG', 'admin', 0);

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `address_table`
--
ALTER TABLE `address_table`
  ADD PRIMARY KEY (`address_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indeks untuk tabel `cart_table`
--
ALTER TABLE `cart_table`
  ADD PRIMARY KEY (`cart_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indeks untuk tabel `category_table`
--
ALTER TABLE `category_table`
  ADD PRIMARY KEY (`category_id`);

--
-- Indeks untuk tabel `contact_table`
--
ALTER TABLE `contact_table`
  ADD PRIMARY KEY (`message_id`);

--
-- Indeks untuk tabel `perkemb_images`
--
ALTER TABLE `perkemb_images`
  ADD PRIMARY KEY (`perkemb_images_id`);

--
-- Indeks untuk tabel `perkemb_table`
--
ALTER TABLE `perkemb_table`
  ADD PRIMARY KEY (`perkemb_id`);

--
-- Indeks untuk tabel `product_cart_table`
--
ALTER TABLE `product_cart_table`
  ADD PRIMARY KEY (`product_cart_id`),
  ADD KEY `cart_id` (`cart_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indeks untuk tabel `product_images`
--
ALTER TABLE `product_images`
  ADD PRIMARY KEY (`product_images_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indeks untuk tabel `product_table`
--
ALTER TABLE `product_table`
  ADD PRIMARY KEY (`product_id`),
  ADD KEY `category_id` (`category_id`),
  ADD KEY `seller_id` (`seller_id`);

--
-- Indeks untuk tabel `review_table`
--
ALTER TABLE `review_table`
  ADD PRIMARY KEY (`review_id`),
  ADD KEY `product_id` (`product_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indeks untuk tabel `user_table`
--
ALTER TABLE `user_table`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `address_table`
--
ALTER TABLE `address_table`
  MODIFY `address_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT untuk tabel `cart_table`
--
ALTER TABLE `cart_table`
  MODIFY `cart_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT untuk tabel `category_table`
--
ALTER TABLE `category_table`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;

--
-- AUTO_INCREMENT untuk tabel `contact_table`
--
ALTER TABLE `contact_table`
  MODIFY `message_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT untuk tabel `perkemb_images`
--
ALTER TABLE `perkemb_images`
  MODIFY `perkemb_images_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT untuk tabel `perkemb_table`
--
ALTER TABLE `perkemb_table`
  MODIFY `perkemb_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT untuk tabel `product_cart_table`
--
ALTER TABLE `product_cart_table`
  MODIFY `product_cart_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `product_images`
--
ALTER TABLE `product_images`
  MODIFY `product_images_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- AUTO_INCREMENT untuk tabel `product_table`
--
ALTER TABLE `product_table`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- AUTO_INCREMENT untuk tabel `review_table`
--
ALTER TABLE `review_table`
  MODIFY `review_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `user_table`
--
ALTER TABLE `user_table`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `address_table`
--
ALTER TABLE `address_table`
  ADD CONSTRAINT `user_address` FOREIGN KEY (`user_id`) REFERENCES `user_table` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `cart_table`
--
ALTER TABLE `cart_table`
  ADD CONSTRAINT `user_cart` FOREIGN KEY (`user_id`) REFERENCES `user_table` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `product_cart_table`
--
ALTER TABLE `product_cart_table`
  ADD CONSTRAINT `product_cart_table_ibfk_1` FOREIGN KEY (`cart_id`) REFERENCES `cart_table` (`cart_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `product_cart_table_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `product_table` (`product_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `product_images`
--
ALTER TABLE `product_images`
  ADD CONSTRAINT `product_images` FOREIGN KEY (`product_id`) REFERENCES `product_table` (`product_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `product_table`
--
ALTER TABLE `product_table`
  ADD CONSTRAINT `product_category` FOREIGN KEY (`category_id`) REFERENCES `category_table` (`category_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `user_product` FOREIGN KEY (`seller_id`) REFERENCES `user_table` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `review_table`
--
ALTER TABLE `review_table`
  ADD CONSTRAINT `product_review` FOREIGN KEY (`product_id`) REFERENCES `product_table` (`product_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `user_review` FOREIGN KEY (`user_id`) REFERENCES `user_table` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
