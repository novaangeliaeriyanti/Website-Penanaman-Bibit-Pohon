<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Perawat extends My_Controller {

	public function __construct() {
		parent::__construct();
		$this->load->model('account_model');
		$this->load->model('admin_model');
		$this->load->model('product_model');
		$this->load->model('category_model');
		$this->load->model('perkemb_model');
		$this->load->model('cart_model');
		$this->load->model('contact_model');
		$this->load->model('user_model');
	}
	
	public function index()	{
		$this->gate_model->perawat_gate();
		$data['newMessagesCount'] = $this->contact_model->getNewMessagesCount();
		$data['messages'] = $this->contact_model->getMessages();
		$this->load->view('layout/perawat/header', array('title' => 'Perawat Dashboard'));
		//$this->loadSidebar(null, null);
		$this->load->view('perawat/dashboard', $data);
		$this->load->view('layout/perawat/footer');
		$this->load->view('layout/perawat/sidebar');
	}
	
	public function read_message($message_id) {
		$this->gate_model->perawat_gate();
		$this->contact_model->readMessage($message_id);
		$data['message'] = $this->contact_model->getMessage($message_id)->row();
		$this->load->view('layout/perawat/header', array('title' => 'Perawat Dashboard'));
		//$this->loadSidebar(null, null);
		$this->load->view('perawat/read_message', $data);
		$this->load->view('layout/perawat/footer');
		$this->load->view('layout/perawat/sidebar');
	}
	
	public function add_perkemb() {
		$this->gate_model->perawat_gate();
		$data["categories"] = $this->category_model->getAllCategoriesWithSubCategories();
		$this->load->view('layout/dashboard/header', array("title" => "Add Perkembangan Pohon"));
		//$this->loadSidebar("show_perkemb", "add_perkemb_active");
		$this->load->view('layout/perawat/sidebar');
		$this->load->view('perawat/add_perkemb',$data);
		$this->load->view('layout/perawat/footer');
	}

	public function view_perkemb() {
		//$this->gate_model->perawat_gate();
		$data["perkemblist"] = $this->perkemb_model->getAllPerkemb();
		$this->load->view('layout/perawat/header', array("title" => "View Perkembangan"));
		//$this->loadSidebar("show_perkemb", "manage_perkemb_active");
		$this->load->view('perawat/view_perkemb',$data);
		$this->load->view('layout/perawat/footer');
		$this->load->view('layout/perawat/sidebar');
	}


	public function edit_perkemb($perkemb_id) {
		$this->gate_model->perawat_gate();
		$data['perkemb'] = $this->perkemb_model->getPerkemb($perkemb_id)->row();
		$data["categories"] = $this->category_model->getAllCategoriesWithSubCategories();
		$data["perkemb_id"] = $perkemb_id;
		$image_link = $this->perkemb_model->getPerkembImageLink($perkemb_id);
		if (count($image_link) == 0){
			$data["image_link"] = 'style/assets/images/no_image.png';
		} else {
			$data["image_link"] = $image_link;
		}
		$this->load->view('layout/perawat/header', array("title" => "Edit Perkembangan"));
		//$this->loadSidebar("show_perkemb", "manage_perkemb_active");
		$this->load->view('perawat/edit_perkemb',$data);
		$this->load->view('layout/perawat/footer');
		$this->load->view('layout/perawat/sidebar');
	}

	public function edit_perkembb($perkemb_id) {
		$this->gate_model->perawat_gate();
		$data['perkemb'] = $this->perkemb_model->getPerkemb($perkemb_id)->row();
		$data["categories"] = $this->category_model->getAllCategoriesWithSubCategories();
		$data["perkemb_id"] = $perkemb_id;
		$image_link = $this->perkemb_model->getPerkembImageLink($perkemb_id);
		if (count($image_link) == 0){
			$data["image_link"] = 'style/assets/images/no_image.png';
		} else {
			$data["image_link"] = $image_link;
		}
		$this->load->view('layout/perawat/header', array("title" => "Edit Perkembangan"));
		//$this->loadSidebar("show_perkemb", "manage_perkemb_active");
		$this->load->view('perawat/edit_perkembb',$data);
		$this->load->view('layout/perawat/footer');
		$this->load->view('layout/perawat/sidebar');
	}

	public function kode_pohon($product_id) {
		//$this->gate_model->pemilik_gate();
		//$data["kode"] = $this->product_model->getAllKode($product_id)->row();
		 $data["sql"] = $this->db->query("SELECT * FROM kode_pohon as a where a.product_id=$product_id");
		$this->load->view('layout/perawat/header', array("title" => "Kode Pohon"));
		//$this->loadSidebar("show_product", "manage_product_active");
		$this->load->view('perawat/kode_view',$data);
		$this->load->view('layout/perawat/footer');
		$this->load->view('layout/perawat/sidebar');
	}

	public function persen($product_id) {
		$mm= $this->product_model->mm();
        $hh= $this->product_model->hh();
        $data["persen"]=$mm;

		$this->load->view('layout/perawat/header', array("title" => "Persen"));
		$this->load->view('perawat/persen',$data);
		$this->load->view('layout/perawat/footer');
		$this->load->view('layout/perawat/sidebar');
	}

	public function hidup($kode_id,$hidup,$product_id) {
		// $this->gate_model->ajax_gate();
		$kode_pohon = $this->product_model->getKode($kode_id);
		$change = $this->product_model->changeStatusKode($kode_id, $hidup);
		if ($change && $hidup == 1) {
			$message = "<div class='alert alert-success alert-dismissable'>";
			$message .= "<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>";
			$message .= "<strong>Success!</strong>!";
			$message .= "</div>";
		} elseif (!$change && $hidup == 1) {
			$message = "<div class='alert alert-danger alert-dismissable'>";
			$message .= "<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>";
			$message .= "<strong>Fail!</strong>";
			$message .= "</div>";
		} elseif($change && $hidup == 0) {
			$message = "<div class='alert alert-success alert-dismissable'>";
			$message .= "<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>";
			$message .= "<strong>Success!</strong>";
			$message .= "</div>";
		} elseif(!$change && $hidup == 0) {
			$message = "<div class='alert alert-danger alert-dismissable'>";
			$message .= "<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>";
			$message .= "<strong>Fail!</strong>t";
			$message .= "</div>";
		}
		$this->session->set_flashdata('msg', $message); 
		redirect('perawat/kode_pohon/'.$product_id);
	}

	public function sakit($kode_id,$sakit,$product_id) {
		// $this->gate_model->ajax_gate();
		$kode_pohon = $this->product_model->getKode($kode_id);
		$change = $this->product_model->changeStatusSakit($kode_id, $sakit);
		if ($change && $sakit == 1) {
			$message = "<div class='alert alert-success alert-dismissable'>";
			$message .= "<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>";
			$message .= "<strong>Success!</strong>!";
			$message .= "</div>";
		} elseif (!$change && $sakit == 1) {
			$message = "<div class='alert alert-danger alert-dismissable'>";
			$message .= "<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>";
			$message .= "<strong>Fail!</strong>";
			$message .= "</div>";
		} elseif($change && $sakit == 0) {
			$message = "<div class='alert alert-success alert-dismissable'>";
			$message .= "<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>";
			$message .= "<strong>Success!</strong>!";
			$message .= "</div>";
		} elseif(!$change && $sakit == 0) {
			$message = "<div class='alert alert-danger alert-dismissable'>";
			$message .= "<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>";
			$message .= "<strong>Fail!</strong>";
			$message .= "</div>";
		}
		$this->session->set_flashdata('msg', $message); 
		redirect('perawat/kode_pohon/'.$product_id);
	}

	public function catatan($kode_id) {
		$this->gate_model->perawat_gate();
		//$data['perkemb'] = $this->perkemb_model->getPerkemb($perkemb_id)->row();
		$kode_pohon = $this->product_model->getKode($kode_id);
		$data["kode_id"] = $kode_id;
		$this->load->view('layout/perawat/header', array("title" => "Catatan"));
		//$this->loadSidebar("show_perkemb", "manage_perkemb_active");
		$this->load->view('perawat/catatan',$data);
		$this->load->view('layout/perawat/footer');
		$this->load->view('layout/perawat/sidebar');
	}
}