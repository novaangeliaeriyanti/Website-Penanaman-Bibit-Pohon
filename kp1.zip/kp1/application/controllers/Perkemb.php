<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Perkemb extends My_Controller {

	public function __construct() {
		parent::__construct();
		$this->load->model('product_model');
		$this->load->model('category_model');
		$this->load->model('cart_model');
		$this->load->model('perkemb_model');
		$this->session->keep_flashdata('msg');
	}

	public function getAllPerkemb() {
		$this->gate_model->ajax_gate();
		header('Access-Control-Allow-Origin: *');
		header('Content-Type: application/json');
		echo json_encode($this->db->get('perkemb_table')->result());
	}

	public function searchActivePerkemb() {
		// $this->gate_model->ajax_gate();
		$search = $_GET['search'];
		header('Access-Control-Allow-Origin: *');
		header('Content-Type: application/json');
		echo json_encode($this->perkemb_model->searchActivePerkemb($search)->result());
	}

	public function searchPerkemb() {
		$this->gate_model->ajax_gate();
		$search = $_GET['search'];
		header('Access-Control-Allow-Origin: *');
		header('Content-Type: application/json');
		echo json_encode($this->perkemb_model->searchPerkemb($search)->result());
	}
	
	public function selectPerkembCart() {
		// $this->gate_model->ajax_gate();
		$cartID = $_GET['cartID'];
		header('Access-Control-Allow-Origin: *');
		header('Content-Type: application/json');
		echo json_encode($this->perkemb_model->getActiveCategoryPerkemb($cartID)->result());
	}
	
	public function getPerkembDataJSON($perkembId) {
		$this->gate_model->ajax_gate();
		header('Access-Control-Allow-Origin: *');
		header('Content-Type: application/json');
		echo json_encode($this->perkemb_model->getPerkemb($perkembId)->result());
	}
	
	public function update($perkemb_id) {
		$this->form_validation->set_rules(
			'product_name', 'Diameter',
			'required|min_length[1]',
			array(
				'required' => '<div class="alert alert-danger">You have not provided %s.</div>',
				'min_length' => '<div class="alert alert-danger">{field} must have at least {param} characters</div>'
			)
		);

		$this->form_validation->set_rules(
			'tinggi_pohon', 'Tinggi Pohon',
			'required|min_length[1]',
			array(
				'required' => '<div class="alert alert-danger">You have not provided %s.</div>',
				'min_length' => '<div class="alert alert-danger">{field} must have at least {param} characters</div>'
			)
		);

		$this->form_validation->set_rules(
			'pohon_mati', 'Jumlah Pohon Mati',
			'required|min_length[1]',
			array(
				'required' => '<div class="alert alert-danger">You have not provided %s.</div>',
				'min_length' => '<div class="alert alert-danger">{field} must have at least {param} characters</div>'
			)
		);

		$this->form_validation->set_rules(
			'perkemb_description', 'Perkembangan Description', 'required|min_length[4]',
			array(
				'required' => '<div class="alert alert-danger">You must provide a %s.</div>',
				'min_length' => '<div class="alert alert-danger">{field} must have at least {param} characters</div>'
				)
		);

		if ($this->form_validation->run() == FALSE) {
			// print_r(validation_errors());
			$this->session->set_flashdata('errors', validation_errors());
			redirect('perawat/edit_perkemb/'.$perkemb_id);
		} else {
			$product_name = $data["lebar"] = $this->input->post('product_name');
			$data["Jumlah_mati"] = $this->input->post('pohon_mati');
			$data["jumlah_sakit"] = $this->input->post('pohon_sakit');
			$data["tinggi"] = $this->input->post('tinggi_pohon');
			$data["description"] = $this->input->post('perkemb_description');
			//$data["product_id"] = $this->input->post('product_id');

			// upload images
			$config['upload_path']          = './uploads/';
			$config['allowed_types']        = 'gif|jpg|png|jpeg';
			$config['max_size']             = 1000;
			$config['max_width']            = 1000000;
			$config['max_height']           = 1000000;

			$this->load->library('upload', $config);

			$upload = $this->upload->do_upload('image_link');
			if ( !$upload && !$this->perkemb_model->getPerkembImageId($perkemb_id)) {
				$error = $this->upload->display_errors();
				$message = "<div class='alert alert-danger alert-dismissable'>";
				$message .= "<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>";
				$message .= "<strong>Fail!</strong> $error";
				$message .= "</div>";
				// print_r($error);
				$this->session->set_flashdata('errors', $message);
				redirect('perawat/edit_perkemb/'.$perkemb_id);
			} elseif(!$upload && count($this->perkemb_model->getPerkembImageId($perkemb_id)) > 0) {
				$update = $this->perkemb_model->updatePerkemb($perkemb_id, $data);
				if ($update) {
					$message = "<div class='alert alert-success alert-dismissable'>";
					$message .= "<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>";
					$message .= "<strong>Success!</strong> $product_name is updated!";
					$message .= "</div>";
				} else {
					$message = "<div class='alert alert-danger alert-dismissable'>";
					$message .= "<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>";
					$message .= "<strong>Fail!</strong> $product_name is not updated!";
					$message .= "</div>";
				}
				$this->session->set_flashdata('msg', $message); 
				redirect('perawat/view_perkemb');
			} elseif ($upload) {
				$file = $this->upload->data();
				$image_link = "uploads/".$file['file_name'];
				$update = $this->perkemb_model->updatePerkembWithPerkembImage($perkemb_id, $data, $image_link);
				if ($update) {
					$message = "<div class='alert alert-success alert-dismissable'>";
					$message .= "<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>";
					$message .= "<strong>Success!</strong> $product_name is updated!";
					$message .= "</div>";
				} else {
					$message = "<div class='alert alert-danger alert-dismissable'>";
					$message .= "<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>";
					$message .= "<strong>Fail!</strong> $product_name is not updated!";
					$message .= "</div>";
				}
				$this->session->set_flashdata('msg', $message); 
				redirect('perawat/view_perkemb');
			}
		}
	}

	public function catatan($kode_id) {
		$this->form_validation->set_rules(
			'catatan', 'Catatan', 'required|min_length[4]',
			array(
				'required' => '<div class="alert alert-danger">You must provide a %s.</div>',
				'min_length' => '<div class="alert alert-danger">{field} must have at least {param} characters</div>'
				)
		);

		if ($this->form_validation->run() == FALSE) {
			// print_r(validation_errors());
			$this->session->set_flashdata('errors', validation_errors());
			redirect('perawat/catatan/'.$kode_id);
		} else {
			$data["catatan"] = $this->input->post('catatan');
			//$data["product_id"] = $this->input->post('product_id');
			$update = $this->perkemb_model->updateCatatan($kode_id, $data);
			$this->session->set_flashdata('msg', $message); 
				redirect('perawat/view_perkemb');
		}
	}

	public function cek_cart()
	{
       $product_cart_id = $this->input->post('product_cart_id');
        //$cek=$this->perkemb_model->getPerkemb($perkembId)->row();
       $cek = $this->db->query("SELECT * FROM product_cart_table WHERE product_cart_id='$product_cart_id'")->row();
		$data = array(
			'product_cart_id' => $cek->product_cart_id,
			'product_id' => $cek->product_id,
			'quantity' => $cek->quantity,
		);

		echo json_encode($data);
	}

	 function get_cart(){
        $product_cart_id=$this->input->post('product_cart_id');
        $data=$this->m_pos->get_data_cart($product_cart_id);
        echo json_encode($data);
    }
	
	public function add() {
		$this->form_validation->set_rules(
			'product_name', 'Diameter',
			'required|min_length[1]',
			array(
				'required' => '<div class="alert alert-danger">You have not provided %s.</div>',
				'min_length' => '<div class="alert alert-danger">{field} must have at least {param} characters</div>'
			)
		);

		$this->form_validation->set_rules(
			'tinggi_pohon', 'Tinggi Pohon',
			'required|min_length[1]',
			array(
				'required' => '<div class="alert alert-danger">You have not provided %s.</div>',
				'min_length' => '<div class="alert alert-danger">{field} must have at least {param} characters</div>'
			)
		);

		$this->form_validation->set_rules(
			'perkemb_description', 'Perkembangan Description', 'required|min_length[2]',
			array(
				'required' => '<div class="alert alert-danger">You must provide a %s.</div>',
				'min_length' => '<div class="alert alert-danger">{field} must have at least {param} characters</div>'
				)
		);
	
		if ($this->form_validation->run() == FALSE) {
			//$data["cart"] = category_model->getAllCategoriesWithSubCategories();
			$this->load->view('layout/perawat/header', array("title" => "Add Perkembangan"));
			//$this->loadSidebar("show_perkemb", "add_perkemb_active");
			$this->load->view('perawat/add_perkemb',$data);
			$this->load->view('layout/perawat/footer');
			$this->load->view('layout/perawat/sidebar');
		} else {
			// Take product details
			$product_name = $data["lebar"] = $this->input->post('product_name');
			$data["tinggi"] = $this->input->post('tinggi_pohon');
			$data["description"] = $this->input->post('perkemb_description');
			$data["product_id"] = $this->input->post('product_id');
			$data["user_id"] =$this->session->userdata('userid');
				$insert = $this->perkemb_model->addPerkemb($data);
				if ($insert) {
					$message = "<div class='alert alert-success alert-dismissable'>";
					$message .= "<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>";
					$message .= "<strong>Success!</strong> $product_name is added!";
					$message .= "</div>";
				} else {
					$message = "<div class='alert alert-danger alert-dismissable'>";
					$message .= "<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>";
					$message .= "<strong>Fail!</strong> Fail to add $product_name";
					$message .= "</div>";
				}
				$this->session->set_flashdata('msg', $message); 
				redirect('perawat/view_perkemb');

		}
	}
	
	public function changeActiveStatus($perkemb_id, $active_flag) {
		// $this->gate_model->ajax_gate();
		$product_name = $this->perkemb_model->getPerkembName($perkemb_id);
		$change = $this->perkemb_model->changeStatus($perkemb_id, $active_flag);
		if ($change && $active_flag == 1) {
			$message = "<div class='alert alert-success alert-dismissable'>";
			$message .= "<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>";
			$message .= "<strong>Success!</strong> $product_name is deactivated!";
			$message .= "</div>";
		} elseif (!$change && $active_flag == 1) {
			$message = "<div class='alert alert-danger alert-dismissable'>";
			$message .= "<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>";
			$message .= "<strong>Fail!</strong> Fail to deactivate $product_name";
			$message .= "</div>";
		} elseif($change && $active_flag == 0) {
			$message = "<div class='alert alert-success alert-dismissable'>";
			$message .= "<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>";
			$message .= "<strong>Success!</strong> $product_name is re-activated!";
			$message .= "</div>";
		} elseif(!$change && $active_flag == 0) {
			$message = "<div class='alert alert-danger alert-dismissable'>";
			$message .= "<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>";
			$message .= "<strong>Fail!</strong> Fail to re-activate $product_name";
			$message .= "</div>";
		}
		$this->session->set_flashdata('msg', $message); 
		redirect('perawat/view_perkemb');
	}

	public function changeActiveStatuss($perkemb_id, $active_flag) {
		// $this->gate_model->ajax_gate();
		$product_name = $this->perkemb_model->getPerkembName($perkemb_id);
		$change = $this->perkemb_model->changeStatus($perkemb_id, $active_flag);
		if ($change && $active_flag == 1) {
			$message = "<div class='alert alert-success alert-dismissable'>";
			$message .= "<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>";
			$message .= "<strong>Success!</strong> $product_name is deactivated!";
			$message .= "</div>";
		} elseif (!$change && $active_flag == 1) {
			$message = "<div class='alert alert-danger alert-dismissable'>";
			$message .= "<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>";
			$message .= "<strong>Fail!</strong> Fail to deactivate $product_name";
			$message .= "</div>";
		} elseif($change && $active_flag == 0) {
			$message = "<div class='alert alert-success alert-dismissable'>";
			$message .= "<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>";
			$message .= "<strong>Success!</strong> $product_name is re-activated!";
			$message .= "</div>";
		} elseif(!$change && $active_flag == 0) {
			$message = "<div class='alert alert-danger alert-dismissable'>";
			$message .= "<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>";
			$message .= "<strong>Fail!</strong> Fail to re-activate $product_name";
			$message .= "</div>";
		}
		$this->session->set_flashdata('msg', $message); 
		redirect('perawat/view_perkemb');
	}
	
	public function addReview() {
		$perkemb_id = $data['perkemb_id'] = $this->input->post('perkemb_id');
		if ($this->session->userdata('usertype') != 'user') {
			$message = "<div class='alert alert-danger alert-dismissable mt-2'>";
			$message .= "<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>";
			$message .= "<strong>Fail!</strong> You are not a valid user and are not allowed to leave a review";
			$message .= "</div>";
		} else {
			$data['user_id'] = $this->session->userdata('userid');
			$data['review'] = $this->input->post('review');
			$data['post_time'] = date("Y-m-d h:i:sa");
			$insert = $this->perkemb_model->addPerkembReview($data);
			if ($insert) {
				$message = "<div class='alert alert-success alert-dismissable mt-2'>";
				$message .= "<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>";
				$message .= "<strong>Success!</strong> Add a review successfully!";
				$message .= "</div>";
			} else {
				$message = "<div class='alert alert-danger alert-dismissable mt-2'>";
				$message .= "<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>";
				$message .= "<strong>Fail!</strong> Fail to add a review";
				$message .= "</div>";
			}
		}
		$this->session->set_flashdata('msg', $message); 
		redirect("shop/product/$perkemb_id");
	}

}
?>