<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Account extends CI_Controller
{

	public function __construct()
	{
		parent::__construct();
		$this->load->model('account_model');
	}

	/**
        Login Page
	 **/
	public function index()
	{
		$this->load->view('layout/account/header', array("title" => "Login"));
		$this->load->view('account/login');
		$this->load->view('layout/account/footer');
	}

	/**
        Registration Page
	 **/
	public function register()
	{
		$this->load->view('layout/account/header', array("title" => "Register Account"));
		$this->load->view('account/register');
		$this->load->view('layout/account/footer');
	}

	/**
		Registration
		Form validation is done here
		password hashing is done here
		redirect to login page if successful
		redirect to registeration page if unsuccessful
	 **/
	public function registerAccount()
	{
		$this->form_validation->set_rules(
			'FName',
			'First Name',
			'trim|required|min_length[2]|max_length[20]|alpha',
			array(
				'required' => 'You have not provided %s.',
				'min_length' => 'Your {field} needs to be at least {param} characters long',
				'max_length' => 'Your {field} needs to be at most {param} characters long',
				'alpha' => 'You may only use alphabet in your {field}'
			)
		);

		$this->form_validation->set_rules(
			'LName',
			'Last Name',
			'trim|required|min_length[2]|max_length[20]|alpha',
			array(
				'required' => 'You have not provided %s.',
				'min_length' => 'Your {field} needs to be at least {param} characters long',
				'max_length' => 'Your {field} needs to be at most {param} characters long',
				'alpha' => 'You may only use alphabet in your {field}'
			)
		);

		$this->form_validation->set_rules(
			'username',
			'Username',
			'trim|required|min_length[4]|max_length[12]|is_unique[user_table.username]|alpha',
			array(
				'required' => 'You have not provided %s.',
				'is_unique' => 'This %s already exists.',
				'alpha' => 'You may only use alphabet and numbers for your username'
			)
		);

		$this->form_validation->set_rules(
			'email',
			'Email',
			'trim|required|is_unique[user_table.email]|valid_email',
			array(
				'required' => 'You have not provided %s.',
				'is_unique' => 'This %s already exists.',
				'valid_email' => 'You did not provide a valid E-Mail Address'
			)
		);

		$this->form_validation->set_rules(
			'password',
			'Password',
			'trim|required',
			array(
				'required' => 'You must provide a %s.'
			)
		);

		$this->form_validation->set_rules(
			'confPassword',
			'Password Confirmation',
			'trim|required|matches[password]',
			array('required' => 'You must provide a %s.')
		);

		if ($this->form_validation->run() == FALSE) {
			$this->register();
		} else {
			$username = $this->input->post('username', TRUE);
			$email = $this->input->post('email', TRUE);
			$FName = $this->input->post('FName', TRUE);
			$LName = $this->input->post('LName', TRUE);
			$user_type = $this->input->post('user_type', TRUE);
			$password = $this->input->post('password', TRUE);
			$confPassword = $this->input->post('confPassword', TRUE);

			$array = array(
				"first_name" => $FName,
				"last_name" => $LName,
				"username" => $username,
				"email" => $email,
				"password" => password_hash($password, PASSWORD_DEFAULT),
				"user_type" => $user_type,
				//"ban_flag" => 1,
				//"is_active" => 0
			);

			//siapkan token
			// $token = base64_encode(random_bytes(32));
			// $user_token = [
			// 	'email' => $email,
			// 	'token' => $token,
			// 	'date_created' => time()
			// ];

			//$this->db->insert('user_token', $user_token);

			//kirim email
			//$this->_sendEmail($token, 'verify');

			if ($this->account_model->register($array)) {
				$this->session->set_flashdata('fail', '<div class="alert alert-success" style="margin-top:10px" role="alert"> Account Registered Successfully! Please check your email to activate your Account!</div>');
				redirect('account');
			} else {
				$this->session->set_flashdata('register', '<div class="alert alert-danger" style="margin-top:10px" role="alert">Failed to register account!</div>');
				redirect('account/register');
			}
		}
	}

	/**
		Signing In
		Checking user type to redirect different dashboards
	 **/
	public function loggingIn()
	{
		$username = $this->input->post("username");
		$password = $this->input->post("password");

		$data = array(
			"username" => $username,
			"password" => $password
		);
		$result = $this->account_model->login($data);
		if ($result == "user") {
			$this->session->set_flashdata('success', '<div class="alert alert-primary mt-4"role="alert">
  				You have successfully logged in as <span href="#" class="alert-link">' . $username . '</span>. Happy browsing.</div>');
			redirect('shop');
		} else if ($result == "admin") {
			$this->session->set_flashdata('success', '<div class="alert alert-primary mt-4" role="alert">
  				You have successfully logged in as <span href="#" class="alert-link">' . $username . '</span>. You are the Admin.</div>');
			redirect('Admin');
		} else if ($result == "perawat") {
			$this->session->set_flashdata('success', '<div class="alert alert-primary mt-4" role="alert">
  				You have successfully logged in as <span href="#" class="alert-link">' . $username . '</span>. You are the Perawat.</div>');
			redirect('perawat');
		} else if ($result == "pemilik") {
			$this->session->set_flashdata('success', '<div class="alert alert-primary mt-4" role="alert">
  				You have successfully logged in as <span href="#" class="alert-link">' . $username . '</span>. You are the Pemilik.</div>');
			redirect('pemilik');
		} else if ($result == "ban") {
			$this->session->set_flashdata('success', '<div class="alert alert-danger mt-4" role="alert">
  				You are banned from this website.</div>');
			redirect('shop1');
		} else {
			$this->session->set_flashdata('fail', '<div class="alert alert-danger mt-4" role="alert">
  				Login failed.</div>');
			redirect('account');
		}
	}

	private function _sendEmail($token, $type)
	{
		$this->load->library('email');

		$config = array();
		$config['protocol'] = 'smtp';
		$config['smtp_host'] = 'ssl://smtp.googlemail.com';
		$config['smtp_user'] = 'undernightsky5@gmail.com';
		$config['smtp_pass'] = 'Ud4hLup4';
		$config['smtp_port'] = 465;
		$config['mailtype'] = 'html';
		$config['charset'] = 'utf-8';
		$this->email->initialize($config);

		$this->email->set_newline("\r\n");

		// $this->load->library('email', $config);
		// $this->email->initialize($config);
		$this->email->from('undernightsky5@gmail.com', 'Tracking Pohon Azeg');
		$this->email->to($this->input->post('email'));
		if ($type == 'verify') {

			$this->email->subject('Account Verification');
			$this->email->message('Click this link to verify ur Account : <a href="' . base_url() . 'index.php/account/verify?email=' . $this->input->post('email') . '&token=' . urlencode($token) . '">Activate</a>');
		} else if ($type == 'forgot') {
			$this->email->subject('Reset Password');
			$this->email->message('Click this link to reset ur Password : <a href="' . base_url() . 'index.php/account/resetpassword?email=' . $this->input->post('email') . '&token=' . urlencode($token) . '">Reset Password</a>');
		}
		if ($this->email->send()) {
			return true;
		} else {
			echo $this->email->print_debugger();
			die;
		}
	}

	public function verify()
	{
		$email = $this->input->get('email');
		$token = $this->input->get('token');

		$user = $this->db->get_where('user_table', ['email' => $email])->row_array();

		if ($user) {
			$user_token = $this->db->get_where('user_token', ['token' => $token])->row_array();

			if ($user_token) {
				if (time() - $user_token['date_created'] < (60 * 60 * 24)) {
					$this->db->set('is_active', 1);
					$this->db->where('email', $email);
					$this->db->update('user_table', ['email' => $email]);

					//delete user token
					$this->db->delete('user_token', ['email' => $email]);

					$this->session->set_flashdata('register', '<div class="alert alert-success" role="alert"> CONGRATULATION! ' . $email . ' HAS BEEN ACTIVATED. PLEASE LOGIN! </div>');
					redirect('account');
				} else {
					$this->db->delete('user_table', ['email' => $email]);
					$this->db->delete('user_token', ['email' => $email]);

					$this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert"> ACCOUNT ACTIVATION FAILED! TOKEN EXPIRED! </div>');
					redirect('account');
				}
			} else {
				$this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert"> ACCOUNT ACTIVATION FAILED! WRONG TOKEN! </div>');
				redirect('account');
			}
		} else {
			$this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert"> ACCOUNT ACTIVATION FAILED! WRONG EMAIL! </div>');
			redirect('account');
		}
	}

	public function forgotpassword()
	{
		$this->form_validation->set_rules('email', 'Email', 'required|trim|valid_email');
		if ($this->form_validation->run() == false) {
			$this->load->view('layout/account/header', array("title" => "Forgot Password"));
			$this->load->view('account/forgot-password');
			$this->load->view('layout/account/footer');
		} else {
			$email = $this->input->post('email');
			$user = $this->db->get_where('user_table', ['email' => $email])->row_array();

			if ($user) {
				$token = base64_encode(random_bytes(32));
				$user_token = [
					'email' => $email,
					'token' => $token,
					'date_created' => time()
				];

				$this->db->insert('user_token', $user_token);
				//kirim email
				$this->_sendEmail($token, 'forgot');

				$this->session->set_flashdata('message', '<div class="alert alert-success" role="alert"> Please check your Email to reset your password ! </div>');
				redirect('account');
			} else {
				$this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert"> EMAIL IS NOT REGISTERED OR ACTIVATED! </div>');
				redirect('account/forgotpassword');
			}
		}
	}

	public function resetpassword()
	{
		$email = $this->input->get('email');
		$token = $this->input->get('token');
		$user = $this->db->get_where('user_table', ['email' => $email])->row_array();

		if ($user) {
			$user_token = $this->db->get_where('user_token', ['token' => $token])->row_array();

			if ($user_token) {
				$this->session->set_userdata('reset_email', $email);
				$this->changepassword();
			} else {
				$this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert"> RESET PASSWORD FAILED! WRONG TOKEN! </div>');
				redirect('account');
			}
		} else {
			$this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert"> RESET PASSWORD FAILED! WRONG EMAIL! </div>');
			redirect('account');
		}
	}

	public function changepassword()
	{
		if (!$this->session->userdata('reset_email')) {
			redirect('account');
		}

		$this->form_validation->set_rules('password1', 'Password', 'required|trim|min_length[6]|matches[password2]', [
			'matches' => 'Password not match!',
			'min_length' => 'Password too short!'
		]);
		$this->form_validation->set_rules('password2', 'Password', 'required|trim|min_length[6]|matches[password1]');
		if ($this->form_validation->run() == false) {
			$this->load->view('layout/account/header', array("title" => "Change Password"));
			$this->load->view('account/change-password');
			$this->load->view('layout/account/footer');
		} else {
			$password = password_hash($this->input->post('password1'), PASSWORD_DEFAULT);
			$email = $this->session->userdata('reset_email');

			$this->db->set('password', $password);
			$this->db->where('email', $email);
			$this->db->update('user_table');

			$this->session->unset_userdata('reset_email');

			$this->session->set_flashdata('message', '<div class="alert alert-success" role="alert"> Password has changed. Please login ! </div>');
			redirect('account');
		}
	}

	/**
        Sign out
	 **/
	public function logout()
	{
		$array_items = array('username', 'usertype');
		$this->session->unset_userdata($array_items);
		redirect('shop');
	}
}
