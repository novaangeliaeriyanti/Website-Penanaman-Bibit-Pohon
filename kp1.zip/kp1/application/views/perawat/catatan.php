<div class="content-wrapper">
  <div class="container-fluid">
    <?php echo $this->session->flashdata("msg"); ?>
    <!-- Breadcrumbs-->
    <ol class="breadcrumb">
      <li class="breadcrumb-item">
        <a href="<?= site_url('perawat');?>">Dashboard</a>
      </li>
      <li class="breadcrumb-item">
        <a href="<?= site_url('perawat/view_perkemb');?>">Catatan Sakit</a>
      </li>
      <li class="breadcrumb-item active">Catatan</li>
    </ol>
    <?= $this->session->flashdata('errors');?>
    <!-- Example DataTables Card-->
    <?= form_open_multipart('perkemb/catatan/'.$kode_id, array('class' => 'form-horizontal')) ?>
    <div class="card mb-3">
      <div class="card-header">
        Catatan
      </div>
      <div class="card-body">

        <div class="form-group">
            <label for="int">Catatan</label>
            <textarea type="text" class="form-control" name="catatan" id="textareaa" ><?php echo $catatan; ?></textarea>
        </div>

        <div class="form-group">
          <input type="submit" value="Update" Class="btn btn-primary form-control">
        </div>
      </div>
    </div>
    <?= form_close(); ?>
  </div>
  <!-- /.container-fluid-->
  <!-- /.content-wrapper-->
</div>




