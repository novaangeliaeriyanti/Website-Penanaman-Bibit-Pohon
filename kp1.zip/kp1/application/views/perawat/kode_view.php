<div class="content-wrapper">
  <div class="container-fluid">
    <?php echo $this->session->flashdata("msg"); ?>
    <!-- Breadcrumbs-->
    <ol class="breadcrumb">
      <li class="breadcrumb-item">
        <a href="<?= site_url('perawat');?>">Dashboard</a>
      </li>
      <li class="breadcrumb-item active">Kode Pohon Anda</li>
    </ol>
    <!-- View Product DataTables Card-->
    <div class="card mb-3">
      <div class="card-header">
        <i class="fa fa-shopping-bag"></i> Kode Pohon </div>
      <div class="card-body">
        <div class="table-responsive">
          <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
            <thead>
              <tr>
                <th width="10%">N0</th>
                <th width="10%">Kode Pohon</th>
                <th width="10%">Keadaan</th>
                <th width="10%">Sakit</th>
                <th width="10%">Catatan</th>
              </tr>
            </thead>
            <tfoot>
              <tr>
                <th width="10%">N0</th>
                <th width="10%">Kode Pohon</th>
                <th width="10%">Keadaan</th>
                <th width="10%">Sakit</th>
                <th width="10%">Catatan</th>
              </tr>
            </tfoot>
            <tbody>
              <?php $count = 1; 
              foreach($sql->result() as $pl) : ?>
                  <tr>
                    <td><?= $count++; ?></td>
                    <td><?= $pl->kode_pohon ?></td>
                     <td>
                      <?php if($pl->hidup == 0): ?>
                        <a href='<?= site_url('perawat/hidup/'.$pl->kode_id.'/1'.'/'.$pl->product_id)?>'>
                          <button class="btn btn-danger" style="width:60%" >Mati</button>
                        </a>
                      <?php elseif($pl->hidup == 1): ?>
                        <a href='<?= site_url('perawat/hidup/'.$pl->kode_id.'/0'.'/'.$pl->product_id)?>'>
                          <button class="btn btn-success" style="width:60%" >Hidup</button>
                        </a>
                      <?php endif; ?>
                    </td>
                     <td>
                      <?php if($pl->sakit == 0): ?>
                        <a href='<?= site_url('perawat/sakit/'.$pl->kode_id.'/1'.'/'.$pl->product_id)?>'>
                          <button class="btn btn-primary" style="width:60%" >Sehat</button>
                        </a>
                      <?php elseif($pl->sakit == 1): ?>
                        <a href='<?= site_url('perawat/sakit/'.$pl->kode_id.'/0'.'/'.$pl->product_id)?>'>
                          <button class="btn btn-danger" style="width:60%" >Sakit</button>
                        </a>
                      <?php endif; ?>
                    </td>
                    <td>
                      <a href='<?= site_url('perawat/catatan/'.$pl->kode_id)?>'>
                        <button class="btn btn-success" style="width:80%">Tambah</button>
                      </a>
                    </td>

                    </tr>
                <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
  <!-- /.container-fluid-->
  <!-- /.content-wrapper-->
</div>
