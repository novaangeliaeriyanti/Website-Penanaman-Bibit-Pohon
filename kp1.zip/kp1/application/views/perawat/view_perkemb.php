<div class="content-wrapper">
  <div class="container-fluid">
    <?php echo $this->session->flashdata("msg"); ?>
    <!-- Breadcrumbs-->
    <ol class="breadcrumb">
      <li class="breadcrumb-item">
        <a href="<?= site_url('perawat');?>">Dashboard</a>
      </li>
      <li class="breadcrumb-item active">List Perkembangan</li>
    </ol>
    <!-- View Product DataTables Card-->
    <div class="card mb-3">
      <div class="card-header">
        <i class="fa fa-shopping-bag"></i> List Perkembangan </div>
      <div class="card-body">
        <div class="table-responsive">
          <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
            <thead>
              <tr>
                <th width="10%">ID</th>
                <th width="20%">Kode Pohon</th>
                <th width="10%">Pohon Mati</th>
                <th width="10%">Pohon Sakit</th>
                <th width="10%">Diameter Pohon</th>
                <th width="10%">Tinggi Pohon</th>
                <th width="20%">Deskripsi</th>
                <!-- <th width="20%">Add Time</th> -->
                <th width="20%">Options</th>
              </tr>
            </thead>
            <tfoot>
              <tr>
                <th>ID</th>
                <th>Kode Pohon</th>
                <th>Pohon Mati</th>
                <th>Pohon Sakit</th>
                <th>Diameter Pohon</th>
                <th>Tinggi Pohon</th>
                <th>Deskripsi</th>
                <!-- <th>Add Time</th> -->
                <th>Options</th>
              </tr>
            </tfoot>
            <tbody>
               <?php 
              $sql = $this->db->get_where('perkemb_table',array("user_id" => $this->session->userdata('userid')));
              

               ?>
              <?php $count = 1; foreach($sql->result() as $prl) : ?>

                  <tr>
                    <td><?= $count++; ?></td>
                    <td>
                      <a href='<?= site_url('perawat/kode_pohon/'.$prl->product_id)?>'>
                        <button class="btn btn-success" style="width:60%">Kode</button>
                      </a>
                    </td>
                    <!-- <td>
                        // $m=$this->db->like('hidup', '0')->from('kode_pohon');
                        // $mm=$this->db->count_all_results();
                        // $h=$this->db->like('hidup', '1')->from('kode_pohon');
                        // $hh=$this->db->count_all_results();
                        // $persen=($mm/($hh+$mm))*100;
                        //  echo $persen;
                     <a href='<?= site_url('perawat/persen/'.$prl->product_id)?>'>
                        <button class="btn btn-success" style="width:60%">Lihat Grafik</button>
                      </a>
                    </td> -->
                     <td><?= $prl->jumlah_mati ?></td>
                     <td><?= $prl->jumlah_sakit ?></td>
                    <td><?= $prl->lebar ?></td>
                    <td><?= $prl->tinggi ?></td>
                    <td><?= $prl->description; ?></td>
                    <!-- <td><?php $date = new DateTime($prl->add_time); echo $date->format('d M Y'); ?></td> -->
                    <!-- <td><a data-toggle='modal' data-target='#editPerkembModal' href='#' onclick="passData(<?= $prl->perkemb_id?>)">Edit</a></td> -->
                    <td>
                      <a href='<?= site_url('perawat/edit_perkembb/'.$prl->perkemb_id)?>'>
                        <button class="btn btn-danger" style="width:60%">Foto</button>
                      </a>
                      <a href='<?= site_url('perawat/edit_perkemb/'.$prl->perkemb_id)?>'>
                        <button class="btn btn-primary" style="width:60%">Edit</button>
                      </a>
                      <!-- <?php if($prl->active_flag == 0): ?>
                        <a href='<?= site_url('perkemb/changeActiveStatus/'.$prl->perkemb_id).'/1'?>'>
                          <button class="btn btn-danger" style="width:100%" >Deactivate</button>
                        </a>
                      <?php elseif($prl->active_flag == 1): ?>
                        <a href='<?= site_url('perkemb/changeActiveStatus/'.$prl->perkemb_id).'/0'?>'>
                          <button class="btn btn-success" style="width:100%" >Re-activate</button>
                        </a>
                      <?php endif; ?> -->
                    </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
  <!-- /.container-fluid-->
  <!-- /.content-wrapper-->
</div>
