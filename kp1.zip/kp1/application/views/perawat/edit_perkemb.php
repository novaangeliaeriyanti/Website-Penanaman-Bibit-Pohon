<div class="content-wrapper">
  <div class="container-fluid">
    <?php echo $this->session->flashdata("msg"); ?>
    <!-- Breadcrumbs-->
    <ol class="breadcrumb">
      <li class="breadcrumb-item">
        <a href="<?= site_url('perawat');?>">Dashboard</a>
      </li>
      <li class="breadcrumb-item">
        <a href="<?= site_url('perawat/view_perkemb');?>">List Perkembangan</a>
      </li>
      <li class="breadcrumb-item active">Edit Perkembangan Pohon</li>
    </ol>
    <?= $this->session->flashdata('errors');?>
    <!-- Example DataTables Card-->
    <?= form_open_multipart('perkemb/update/'.$perkemb_id, array('class' => 'form-horizontal')) ?>
    <div class="card mb-3">
      <div class="card-header">
        Edit Perkembangan
      </div>
      <div class="card-body">
        <div class="form-group">
          <?php if(isset($image_error)) {echo $image_error; }?>
          <label class="control-label">Image</label>
          <div class="row">
            <div class="col-md-4">
              <img src="<?= base_url($image_link); ?>" id="perkemb_image" name="perkemb_image" class="img-thumbnail">
              <input type="file" id="my_file" onchange="readURL(this);" accept='image/*' name="image_link"/>
            </div>
          </div>
        </div>

        <div class="form-group">
          <?= form_error('product_name'); ?>
          <label class="control-label">Diameter Pohon</label>
          <div>
            <input id="product_name" type="text" class="form-control" name="product_name" value="<?= $perkemb->lebar; ?>">
          </div>
        </div>

        <div class="form-group">
          <?= form_error('tinggi_pohon'); ?>
          <label class="control-label">Tinggi Pohon</label>
          <div>
            <input id="tinggi_pohon" type="text" class="form-control" name="tinggi_pohon" value="<?= $perkemb->tinggi; ?>">
          </div>
        </div>

        <div class="form-group">
          <?= form_error('pohon_mati'); ?>
          <label class="control-label">Jumlah Pohon Mati</label>
          <div>
            <input id="pohon_mati" type="text" class="form-control" name="pohon_mati" value="<?= $perkemb->jumlah_mati; ?>">
          </div>
        </div>

        <div class="form-group">
          <?= form_error('pohon_sakit'); ?>
          <label class="control-label">Jumlah Pohon Sakit</label>
          <div>
            <input id="pohon_sakit" type="text" class="form-control" name="pohon_sakit" value="<?= $perkemb->jumlah_sakit; ?>">
          </div>
        </div>
<!-- 
        <div class="form-group">
          <?= form_error('description'); ?>
          <label class="control-label">Description</label>
          <div>
            <textarea id="textarea" name="perkemb_description" readonly><?= $perkemb->description; ?></textarea>
          </div>
        </div> -->

        <div class="form-group">
            <label for="int">Deskripsi</label>
            <textarea type="text" class="form-control" name="perkemb_description" id="textareaa" ><?php echo $perkemb->description; ?></textarea>
        </div>

        <div class="form-group">
          <input type="submit" value="Update" Class="btn btn-primary form-control">
        </div>
      </div>
    </div>
    <?= form_close(); ?>
  </div>
  <!-- /.container-fluid-->
  <!-- /.content-wrapper-->
</div>

<script>
  function readURL(input) {
    if (input.files && input.files[0]) {
        var reader = new FileReader();

        reader.onload = function (e) {
            $('#perkemb_image')
                .attr('src', e.target.result)
                .width(300)
                .height(300);
        };

        reader.readAsDataURL(input.files[0]);
    }
  }
</script>



