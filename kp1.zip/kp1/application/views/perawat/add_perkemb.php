<div class="content-wrapper">
  <div class="container-fluid">
    <?php echo $this->session->flashdata("msg"); ?>
    <!-- Breadcrumbs-->
    <ol class="breadcrumb">
      <li class="breadcrumb-item">
        <a href="<?= site_url('perawat');?>">Dashboard</a>
      </li>
      <li class="breadcrumb-item active">Add Perkembangan Pohon</li>
    </ol>
    <!-- Example DataTables Card-->
<!-- <?= form_open_multipart('perkemb/add', array('class' => 'form-horizontal')) ?> -->
<form class="form-horizontal" action="<?php echo site_url('perkemb/add');?>"  method="POST" enctype="multipart/form-data">
    <div class="card mb-3">
      <div class="card-header">
        Add Perkembangan Pohon
      </div>

      <div class="card-body">

        <div class="form-group">
          <label>Product Name</label><br>
            <select id="product_id" name="product_id"  class="form-control" >
              <?php 
              $sql = $this->db->get('product_table');
              foreach ($sql->result() as $row) {
               ?>
              <option value="<?php echo $row->product_id ?>"><?php echo $row->product_name ?></option>
              <?php } ?>
            </select>
         </div>

        <div class="form-group">
          <?= form_error('product_name'); ?>
          <label class="control-label">Diameter Pohon</label>
          <div>
            <input id="product_name" type="text" class="form-control" name="product_name" value="<?php echo set_value('product_name'); ?>">
          </div>
        </div>

        <div class="form-group">
          <?= form_error('tinggi_pohon'); ?>
          <label class="control-label">Tinggi Pohon</label>
          <div>
            <input id="tinggi_pohon" type="text" class="form-control" name="tinggi_pohon" value="<?php echo set_value('tinggi_pohon'); ?>">
          </div>
        </div>

        <div class="form-group">
          <?= form_error('perkemb_description'); ?>
          <label class="control-label">Perkembangan Description</label>
            <div>
            <input id="perkemb_description" type="text" class="form-control" name="perkemb_description" value="<?php echo set_value('perkemb_description'); ?>">
          </div>
        </div>
      
        <div class="form-group">
          <input type="submit" value="Add" Class="btn btn-primary form-control">
        </div>
      </div>

    </div>
<!-- <?= form_close(); ?>  -->
</form>  
  </div>
</div>
