<div class="content-wrapper">
  <div class="container-fluid">
    <?php echo $this->session->flashdata("msg"); ?>
    <!-- Breadcrumbs-->
    <ol class="breadcrumb">
      <li class="breadcrumb-item">
        <a href="<?= site_url('perawat');?>">Dashboard</a>
      </li>
      <li class="breadcrumb-item active">List Perkembangan</li>
    </ol>
    <!-- View Product DataTables Card-->
    <div class="card mb-3">
      <div class="card-header">
        <i class="fa fa-shopping-bag"></i> Persen Keadaan </div>
      <div class="card-body">
        <div class="table-responsive">
          <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
            <thead>
              <tr>
                <th width="10%">Persen</th>
              </tr>
            </thead>
            <tfoot>
              <tr>
                <th>Persen Keadaan</th>
   
              </tr>
            </tfoot>
            <tbody>
               <!-- <?php 
              $sql = $this->db->get_where('perkemb_table',array("user_id" => $this->session->userdata('userid')));
              

               ?> -->
              <?php foreach($persen as $prl) : ?>

                  <tr>
                    
                    <td><?= $prl ?></td>
                    
                    </tr>
                <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
  <!-- /.container-fluid-->
  <!-- /.content-wrapper-->
</div>
