<div class="content-wrapper">
  <div class="container-fluid">
    <?php echo $this->session->flashdata("msg"); ?>
    <!-- Breadcrumbs-->
    <ol class="breadcrumb">
      <li class="breadcrumb-item">
        <a href="<?= site_url('user');?>">Dashboard</a>
      </li>
      <li class="breadcrumb-item">
        <a href="<?= site_url('user/view_perkemb');?>">List Perkembangan</a>
      </li>
      <li class="breadcrumb-item active">Foto Perkembangan Pohon</li>
    </ol>
    <?= $this->session->flashdata('errors');?>
    <!-- Example DataTables Card-->
    <?= form_open_multipart('user/foto/'.$perkemb_id, array('class' => 'form-horizontal')) ?>
    <div class="card mb-3">
      <div class="card-header">
        Foto Perkembangan
      </div>
      <div class="card-body">
        <div class="form-group">
          <?php if(isset($image_error)) {echo $image_error; }?>
          <div class="row">
            <div class="col-md-4">
              <img src="<?= base_url($image_link); ?>" id="perkemb_image" name="perkemb_image" class="img-thumbnail" width="1500px">
            </div>
          </div>
        </div>
    </div>
    <?= form_close(); ?>
  </div>
  <!-- /.container-fluid-->
  <!-- /.content-wrapper-->
</div>

<script>
  function readURL(input) {
    if (input.files && input.files[0]) {
        var reader = new FileReader();

        reader.onload = function (e) {
            $('#perkemb_image')
                .attr('src', e.target.result)
                .width(300)
                .height(300);
        };

        reader.readAsDataURL(input.files[0]);
    }
  }
</script>



