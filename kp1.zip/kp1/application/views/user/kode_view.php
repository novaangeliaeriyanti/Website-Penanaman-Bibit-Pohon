<div class="content-wrapper">
  <div class="container-fluid">
    <?php echo $this->session->flashdata("msg"); ?>
    <!-- Breadcrumbs-->
    <ol class="breadcrumb">
      <li class="breadcrumb-item">
        <a href="<?= site_url('user');?>">Dashboard</a>
      </li>
      <li class="breadcrumb-item active">Pohon Mati</li>
    </ol>
    <!-- View Product DataTables Card-->
    <div class="card mb-3">
      <div class="card-header">
        <i class="fa fa-shopping-bag"></i>Pohon Mati</div>
      <div class="card-body">
        <div class="table-responsive">
          <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
            <thead>
              <tr>
                <th width="10%">N0</th>
                <th width="10%">Kode Pohon</th>
                <th width="30%">Catatan</th>
              </tr>
            </thead>
            <tfoot>
              <tr>
                <th width="10%">N0</th>
                <th width="10%">Kode Pohon</th>
                <th width="30%">Catatan</th>
              </tr>
            </tfoot>
            <tbody>
              <?php $count = 1; 
              foreach($sql->result() as $pl) : ?>
                  <tr>
                    <td><?= $count++; ?></td>
                    <td><?= $pl->kode_pohon ?></td>
                    <td><?= $pl->catatan ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
  <!-- /.container-fluid-->
  <!-- /.content-wrapper-->
</div>
