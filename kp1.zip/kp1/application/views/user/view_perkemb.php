<div class="content-wrapper">
  <div class="container-fluid">
    <?php echo $this->session->flashdata("msg"); ?>
    <!-- Breadcrumbs-->
    <ol class="breadcrumb">
      <li class="breadcrumb-item">
        <a href="<?= site_url('user');?>">Dashboard</a>
      </li>
      <li class="breadcrumb-item active">List Perkembangan</li>
    </ol>
    <!-- View Product DataTables Card-->
    <div class="card mb-3">
      <div class="card-header">
        <i class="fa fa-shopping-bag"></i> List Perkembangan </div>
      <div class="card-body">
        <div class="table-responsive">
          <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
            <thead>
              <tr>
                <th width="5%">ID</th>
                <th width="10%">Diameter(cm)</th>
                <th width="10%">Tinggi(cm)</th>
                <th width="20%">Deskripsi</th>
                <th width="20%">Catatan Pohon Mati</th>
                <th width="20%">Catatan Pohon Sakit</th>
                <th width="10%">Pohon Mati</th>
                <th width="10%">Pohon Sakit</th>
                <!-- <th width="20%">Add Time</th> -->
                <th width="10%">Options</th>
              </tr>
            </thead>
            <tfoot>
              <tr>
                <th>ID</th>
                <th>Diameter(cm)</th>
                <th>Tinggi(cm)</th>
                <th>Kode Pohon Mati</th>
                <th>Catatan Pohon Sakit</th>
                <th>Pohon Mati</th>
                <th>Pohon Sakit</th>
                <!-- <th>Add Time</th> -->
                <th>Options</th>
              </tr>
            </tfoot>
            <tbody>
               <?php 
              $sql = $this->db->get_where('perkemb_table');
               ?>
              <?php $count = 1; foreach($sql->result() as $prl) : ?>

                  <tr>
                    <td><?= $count++; ?></td>
                    <td><?= $prl->lebar ?></td>
                    <td><?= $prl->tinggi ?></td>
                    <td><?= $prl->description; ?></td>
                    <td>
                      <a href='<?= site_url('user/kode_pohon/'.$prl->product_id)?>'>
                        <button class="btn btn-success" style="width:60%">Lihat</button>
                      </a>
                    </td>

                    <td>
                      <a href='<?= site_url('user/sakit/'.$prl->product_id)?>'>
                        <button class="btn btn-danger" style="width:60%">Lihat</button>
                      </a>
                    </td>

                    <td><?= $prl->jumlah_mati; ?></td>
                    <td><?= $prl->jumlah_sakit; ?></td>
                    <!-- <td><?php $date = new DateTime($prl->add_time); echo $date->format('d M Y'); ?></td> -->
                    <!-- <td><a data-toggle='modal' data-target='#editPerkembModal' href='#' onclick="passData(<?= $prl->perkemb_id?>)">Edit</a></td> -->
                    <td>
                      <a href='<?= site_url('user/edit_perkemb/'.$prl->perkemb_id)?>'>
                        <button class="btn btn-primary" style="width:100%">Foto</button>
                      </a>
                    </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
  <!-- /.container-fluid-->
  <!-- /.content-wrapper-->
</div>
