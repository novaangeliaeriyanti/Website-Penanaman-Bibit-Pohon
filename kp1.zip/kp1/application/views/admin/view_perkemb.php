<div class="content-wrapper">
  <div class="container-fluid">
    <?php echo $this->session->flashdata("msg"); ?>
    <!-- Breadcrumbs-->
    <ol class="breadcrumb">
      <li class="breadcrumb-item">
        <a href="<?= site_url('admin');?>">Dashboard</a>
      </li>
      <li class="breadcrumb-item active">List Perkembangan</li>
    </ol>
    <!-- View Product DataTables Card-->
    <div class="card mb-3">
      <div class="card-header">
        <i class="fa fa-shopping-bag"></i> List Perkembangan </div>
      <div class="card-body">
        <div class="table-responsive">
          <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
            <thead>
              <tr>
                <th width="10%">ID</th>
                <th width="20%">Diameter Pohon</th>
                <th width="20%">Description</th>
                <!-- <th width="20%">Add Time</th> -->
                <th width="10%">Options</th>
              </tr>
            </thead>
            <tfoot>
              <tr>
                <th>ID</th>
                <th>Diameter Pohon</th>
                <th>Description</th>
                <!-- <th>Add Time</th> -->
                <th>Options</th>
              </tr>
            </tfoot>
            <tbody>
               <?php 
              $sql = $this->db->get('perkemb_table');
               ?>
              <?php $count = 1; foreach($sql->result() as $prl) : ?>
                  <tr>
                    <td><?= $count++; ?></td>
                    <td><?= $prl->lebar ?></td>
                    <td><?= $prl->description; ?></td>
                    <!-- <td><?php $date = new DateTime($prl->add_time); echo $date->format('d M Y'); ?></td> -->
                    <!-- <td><a data-toggle='modal' data-target='#editPerkembModal' href='#' onclick="passData(<?= $prl->perkemb_id?>)">Edit</a></td> -->
                    <td>
                      <?php if($prl->active_flag == 0): ?>
                        <a href='<?= site_url('perkemb/changeActiveStatuss/'.$prl->perkemb_id).'/1'?>'>
                          <button class="btn btn-danger" style="width:100%" >Deactivate</button>
                        </a>
                      <?php elseif($prl->active_flag == 1): ?>
                        <a href='<?= site_url('perkemb/changeActiveStatuss/'.$prl->perkemb_id).'/0'?>'>
                          <button class="btn btn-success" style="width:100%" >Re-activate</button>
                        </a>
                      <?php endif; ?>
                    </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
  <!-- /.container-fluid-->
  <!-- /.content-wrapper-->
</div>
