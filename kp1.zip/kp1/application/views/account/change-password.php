<body style="min-height: 350px; background:linear-gradient( rgba(0, 0, 0, 0.8), rgba(0, 0, 0, 0.8) ), url(<?= base_url('style/assets/images/hero-aerial-forest-evergreen-trees.jpg') ?>) no-repeat center center fixed;-webkit-background-size: cover;-moz-background-size: cover;-o-background-size: cover; background-size: cover;">
    <div class="container">
        <?php echo $this->session->flashdata("fail"); ?>
        <h1 class="text-center mt-5" style="color:white; font-family: 'Lobster', cursive">Change Your Password For </h1>
        <h2 class="text-center mt-2" style="color:white; font-family: 'Lobster', cursive"><?= $this->session->userdata('reset_email'); ?></h2>
        <div class="card card-login mx-auto mt-2">
            <div class="card-body">
                <?php echo form_open('account/changepassword'); ?>
                <div class="form-group">
                    <label for="exampleInputEmail1">Enter New Password</label>
                    <input class="form-control" id="password1" name="password1" type="password" placeholder="Enter New Password" required>
                </div>
                <div class="form-group">
                    <input class="form-control" id="password2" name="password2" type="password" placeholder="Re-Enter New Password" required>
                </div>
                <button class="btn btn-primary btn-block" type=" submit">Change Password</button>
                </form>
            </div>
        </div>
    </div>
    <!-- Bootstrap core JavaScript-->
    <script src="<?php echo base_url(); ?>style/vendor/jquery/jquery.min.js"></script>
    <script src="<?php echo base_url(); ?>style/vendor/popper/popper.min.js"></script>
    <script src="<?php echo base_url(); ?>style/vendor/bootstrap/js/bootstrap.min.js"></script>
    <!-- Core plugin JavaScript-->
    <script src="<?php echo base_url(); ?>style/vendor/js/jquery.easing.min.js"></script>
</body>

<!-- <div class="container">

    
    <div class="row justify-content-center">

        <div class="col-7">

            <div class="card o-hidden border-0 shadow-lg my-5">
                <div class="card-body p-0">

                    <div class="row">
                        <div class="col-lg">
                            <div class="p-5">
                                <div class="text-center">
                                    <h1 class="h4 text-gray-900 ">Change your Password for</h1>
                                    <h5 class="mb-4"><?= $this->session->userdata('reset_email'); ?></h5>
                                </div>

                                <?= $this->session->flashdata('message'); ?>

                                <form class="user" method="post" action="<?= base_url('auth/changepassword'); ?>">
                                    <div class="form-group">
                                        <input type="password" class="form-control form-control-user" id="password1" name="password1" placeholder="Enter New Password...">
                                        <?= form_error('password1', '<small class="text-danger pl-3">', '</small>') ?>
                                    </div>
                                    <div class="form-group">
                                        <input type="password" class="form-control form-control-user" id="password2" name="password2" placeholder="Re-Enter New Password...">
                                        <?= form_error('password2', '<small class="text-danger pl-3">', '</small>') ?>
                                    </div>
                                    <button type="submit" class="btn btn-primary btn-user btn-block">
                                        Change Password
                                    </button>
                                    <hr>

                                </form>
                                <hr>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>

    </div>

</div> -->