<div class="content-wrapper">
  <div class="container-fluid">
    <?php echo $this->session->flashdata("msg"); ?>
    <!-- Breadcrumbs-->
    <ol class="breadcrumb">
      <li class="breadcrumb-item">
        <a href="<?= site_url('pemilik');?>">Dashboard</a>
      </li>
      <li class="breadcrumb-item active">Data Perkembangan</li>
    </ol>
    <!-- View Product DataTables Card-->
    <div class="card mb-3">
      <div class="card-header">
        <i class="fa fa-shopping-bag"></i> Data Perkembangan </div>
      <div class="card-body">
        <div class="table-responsive">
          <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
            <thead>
              <tr>
                <th width="10%">ID</th>
                <th width="20%">Diameter Pohon</th>
                <th width="20%">Deskripsi</th>
                <!-- <th width="20%">Add Time</th> -->
              </tr>
            </thead>
            <tfoot>
              <tr>
                <th>ID</th>
                <th>Diameter Pohon</th>
                <th>Deskripsi</th>
                <!-- <th>Add Time</th> -->
              </tr>
            </tfoot>
            <tbody>
               <?php 
              $sql = $this->db->get('perkemb_table');
               ?>
              <?php $count = 1; foreach($sql->result() as $prl) : ?>
                  <tr>
                    <td><?= $count++; ?></td>
                    <td><?= $prl->lebar ?></td>
                    <td><?= $prl->description; ?></td>
                    <!-- <td><?php $date = new DateTime($prl->add_time); echo $date->format('d M Y'); ?></td> -->
                    <!-- <td><a data-toggle='modal' data-target='#editPerkembModal' href='#' onclick="passData(<?= $prl->perkemb_id?>)">Edit</a></td> -->
                    </tr>
                <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
  <!-- /.container-fluid-->
  <!-- /.content-wrapper-->
</div>
