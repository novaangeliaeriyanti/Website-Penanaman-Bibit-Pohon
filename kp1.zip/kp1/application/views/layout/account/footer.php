
</html>
<script src="<?php echo base_url();?>style/vendor/jquery/jquery.min.js"></script>
<script src="<?php echo base_url();?>style/vendor/popper/popper.min.js"></script>
<script src="<?php echo base_url();?>style/js/shop.js"></script>
<script src="<?php echo base_url();?>style/vendor/bootstrap/js/bootstrap.min.js"></script>

<script type="text/javascript">
		window.setTimeout(function() {
    $(".alert").fadeTo(500, 0).slideUp(500, function(){
        $(this).remove(); 
    });
}, 4000);
</script>