	<nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top" id="mainNav">
		<a class="navbar-brand" href="<?php echo base_url().'index.php/pemilik'?>">Pemilik Dashboard</a>
		<button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
			<span class="navbar-toggler-icon"></span>
		</button>
		<div class="collapse navbar-collapse" id="navbarResponsive">
			<ul class="navbar-nav navbar-sidenav" id="exampleAccordion">
				<!-- <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Dashboard">
					<a class="nav-link" href="<?= site_url('shop'); ?>">
						<i class="fa fa-fw fa-dashboard"></i>
						<span class="nav-link-text">Go to Site</span>
					</a>
				</li> -->
				<!-- <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Users">
					<a class="nav-link nav-link-collapse collapsed" data-toggle="collapse" href="#collapseMulti2" data-parent="#exampleAccordion">
						<i class="fa fa-fw fa-users"></i>
						<span class="nav-link-text">Users</span>
					</a>
					<ul class="sidenav-second-level collapse <?= $show_user; ?>" id="collapseMulti2">
						<li class="<?= $manage_user_active; ?>">
							<a href="<?= site_url('pemilik/view_users'); ?>">Manage</a>
						</li>
					</ul>
				</li> -->
				<li class="nav-item" data-toggle="tooltip" data-placement="right" title="Products">
					<a class="nav-link nav-link-collapse" data-toggle="collapse" href="#collapseMulti3" data-parent="#exampleAccordion">
						<i class="fa fa-fw fa-tree"></i>
						<span class="nav-link-text">Lahan</span>
					</a>
					<ul class="sidenav-second-level collapse <?= $show_product; ?>" id="collapseMulti3">
						<li class="<?= $manage_product_active; ?>">
							<a href="<?= site_url('pemilik/view_product'); ?>">Data Lahan</a>
						</li>
						<li class="<?= $add_product_active; ?>">
							<a href="<?= site_url('pemilik/add_product'); ?>">Tambah</a>
						</li>
					</ul>
				</li>
				<li class="nav-item" data-toggle="tooltip" data-placement="right" title="Categories">
					<a class="nav-link nav-link-collapse" data-toggle="collapse" href="#collapseMulti4" data-parent="#exampleAccordion">
						<i class="fa fa-fw fa-tree"></i>
						<span class="nav-link-text">Jenis Pohon</span>
					</a>
					<ul class="sidenav-second-level collapse <?= $show_category; ?>" id="collapseMulti4">
						<li class="<?= $manage_category_active; ?>">
							<a href="<?= site_url('pemilik/view_category'); ?>">Data Jenis Pohon</a>
						</li>
						<li class="<?= $add_category_active; ?>">
							<a href="<?= site_url('pemilik/add_category'); ?>">Tambah</a>
						</li>
					</ul>
				</li>
				<li class="nav-item" data-toggle="tooltip" data-placement="right" title="Perkemb">
					<a class="nav-link nav-link-collapse" data-toggle="collapse" href="#collapseMulti5" data-parent="#exampleAccordion">
						<i class="fa fa-fw fa-tree"></i>
						<span class="nav-link-text">Perkembangan Pohon</span>
					</a>
					<ul class="sidenav-second-level collapse <?= $show_perkemb; ?>" id="collapseMulti5">
						<li class="<?= $manage_perkemb_active; ?>">
							<a href="<?= site_url('pemilik/view_perkemb'); ?>">Data Perkembangan</a>
						</li>
					</ul>
				</li>
<!-- 				<li class="nav-item" data-toggle="tooltip" data-placement="right" title="Orders and Cart">
					<a class="nav-link nav-link-collapse" data-toggle="collapse" href="#collapseMulti6" data-parent="#exampleAccordion">
						<i class="fa fa-fw fa-shopping-cart"></i>
						<span class="nav-link-text">Transaksi</span>
					</a>
					<ul class="sidenav-second-level collapse <?= $show_order; ?>" id="collapseMulti6">
						<li class="<?= $manage_order_active; ?>">
							<a href="<?= site_url('pemilik/manage_order'); ?>">Trasaksi Masuk</a>
						</li>
					</ul>
				</li> -->
			</ul>
			<ul class="navbar-nav sidenav-toggler">
				<li class="nav-item">
					<a class="nav-link text-center" id="sidenavToggler">
						<i class="fa fa-fw fa-angle-left"></i>
					</a>
				</li>
			</ul>
			<ul class="navbar-nav ml-auto">

				<li class="nav-item">
					<a class="nav-link" data-toggle="modal" data-target="#logoutmodal">
						<i class="fa fa-fw fa-sign-out"></i>Logout</a>
				</li>
			</ul>
		</div>
	</nav>