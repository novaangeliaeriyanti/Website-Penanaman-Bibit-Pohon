<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Kode_model extends CI_Model
{

    // function buat_kode_pohon()   {    
    //   $this->db->select('RIGHT(kode_pohon.kode_id,4) as kode', FALSE);
    //   $this->db->order_by('kode_id','DESC');    
    //   $this->db->limit(1);     
    //   $query = $this->db->get('kode_pohon');      //cek dulu apakah ada sudah ada kode di tabel.    
    //   if($query->num_rows() <> 0){       
    //    //jika kode ternyata sudah ada.      
    //    $data = $query->row();      
    //    $kode = intval($data->kode) + 1;     
    //   }
    //   else{       
    //    //jika kode belum ada      
    //    $kode = 1;     
    //   }
    //   $kodemax = str_pad($kode, 4, "0", STR_PAD_LEFT);    
    //   $kodejadi = "PHN".$kodemax;     
    //   return $kodejadi;  
    //  }

     // function buat_kode_pohon()   {    
     //  $this->db->select('RIGHT(product_cart_table.product_cart_id,4) as kode', FALSE);
     //  $this->db->order_by('product_cart_id','DESC');    
     //  $this->db->limit(1);     
     //  $query = $this->db->get('product_cart_table');      //cek dulu apakah ada sudah ada kode di tabel.    
     //  if($query->num_rows() <> 0){       
     //   //jika kode ternyata sudah ada.      
     //   $data = $query->row();      
     //   $kode = intval($data->kode) + 1;     
     //  }
     //  else{       
     //   //jika kode belum ada      
     //   $kode = 1;     
     //  }
     //  $kodemax = str_pad($kode, 4, "0", STR_PAD_LEFT);    
     //  $kodejadi = "PHN".$kodemax;     
     //  return $kodejadi;  
     // }

   // function buat_kode_pohon()   {    
   //    $this->db->select('RIGHT(product_table.kode_id,4) as kode', FALSE);
   //    $this->db->order_by('kode_id','DESC');    
   //    $this->db->limit(1);     
   //    $query = $this->db->get('product_table');      //cek dulu apakah ada sudah ada kode di tabel.    
   //    if($query->num_rows() <> 0){       
   //     //jika kode ternyata sudah ada.      
   //     $data = $query->row();      
   //     $kode = intval($data->kode) + 1;     
   //    }
   //    else{       
   //     //jika kode belum ada      
   //     $kode = 1;     
   //    }
   //    $kodemax = str_pad($kode, 4, "0", STR_PAD_LEFT);    
   //    $kodejadi = "PHN".$kodemax;     
   //    return $kodejadi;  
   //   }

     function buat_kode_pohon()   {    
      $this->db->select('RIGHT(kode_pohon.kode_pohon,4) as kode', FALSE);
      $this->db->order_by('kode_pohon','DESC');    
      $this->db->limit(1);     
      $query = $this->db->get
      ('kode_pohon');      //cek dulu apakah ada sudah ada kode di tabel.    
      if($query->num_rows() <> 0){       
       //jika kode ternyata sudah ada.      
       $data = $query->row();      
       $kode = intval($data->kode) + 1;     
      }
      else{       
       //jika kode belum ada      
       $kode = 1;     
      }
      $kodemax = str_pad($kode, 4, "0", STR_PAD_LEFT);    
      $kodejadi = "POHON".$kodemax;     
      return $kodejadi;  
     }

}
