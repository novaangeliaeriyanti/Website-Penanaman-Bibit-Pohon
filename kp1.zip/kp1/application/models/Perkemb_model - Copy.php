<?php

class Perkemb_model extends CI_Model {

	public function getAllPerkemb() {
		return $this->db->join(CATEGORY, "catt.category_id = pr.category_id")->get(perkemb);
	}

	public function getSixPerkemb() {
		return $this->db->limit(6)->get(perkemb);
	}

	public function getPerkemb($perkemb_id = "") {
		return $this->db
			->join('perkemb_images pi', 'pi.perkemb_id = pr.perkemb_id', 'left')
			->get_where('perkemb_table pr', array("pr.perkemb_id" => $perkemb_id));
	}

	public function getCategoryProduct($category_id = "") {
		return $this->db->join(CATEGORY, "catt.category_id = pr.category_id")->get_where(perkemb, array("pr.category_id" => $category_id));
	}

	public function getActiveCategoryPerkemb($category_id = "") {
		return $this->db
			->join('perkemb_images pi', 'pi.perkemb_id = pr.perkemb_id')
			->get_where(perkemb, array("category_id" => $category_id, "activeflag" => 0));
	}

	public function addPerkemb($array, $image_link) {
		$insert = $this->db->insert("perkemb_table", $array);
		$perkemb_id = $this->db->insert_id();
		$this->db->insert('perkemb_images', array('perkemb_id' => $perkemb_id, "image_link" => $image_link));
		return $insert;
	}

	public function updatePerkembWithPerkembImage($perkemb_id, $array, $image_link) {
		$update = $this->db->where("perkemb_id", $perkemb_id)->update(perkemb, $array);
		$perkembImageId = $this->getPerkembImageId($perkemb_id);
		if (!$perkembImageId) {
			$this->db->insert('perkemb_images', array('perkemb_id' => $perkemb_id, "image_link" => $image_link));
		} else {
			$image_path = $_SERVER['DOCUMENT_ROOT'].'/codeigniter/'.$this->getPerkembImageLink($perkemb_id);
			unlink($image_path);
			$this->db->where(array('perkemb_id' => $perkemb_id))->update('perkemb_images', array("image_link" => $image_link));
		}
		return $update;
	}

	public function updatePerkemb($perkemb_id, $array) {
		return $this->db->where("perkemb_id", $perkemb_id)->update(perkemb, $array);
	}

	public function searchPerkemb($search = "") {
		return $this->db->like('product_name', "$search")->get(perkemb);
	}

	public function searchActivePerkemb($search = "") {
		return $this->db
			->join('perkemb_images pri', 'pri.perkemb_id = pr.perkemb_id')
			->like('product_name', "$search")->get_where(perkemb, array("activeflag" => 0));
	}

	public function changeStatus($perkemb_id, $activeflag) {
		return $this->db->where('perkemb_id', $perkemb_id)->update(perkemb, array('activeflag' => $activeflag));
	}
	
	public function getPerkembName ($perkemb_id) {
		return $this->db->where('perkemb_id', $perkemb_id)->get('perkemb_table')->row()->product_name;
	}

	public function getActivePerkemb() {
		return $this->db
		->join('perkemb_images pri', 'pri.perkemb_id = pr.perkemb_id')
		->get_where('perkemb_table pr', array('pr.activeflag' => 0))->result();
	}

	public function getPerkembImageLink($perkemb_id) {
		$image = $this->db->get_where('perkemb_images', array('perkemb_id' => $perkemb_id))->row();
		if (count($image) != 0) {
			return $image->image_link;
		} else {
			return null;
		}
	}

	public function getPerkembImageId($perkemb_id) {
		$image = $this->db->get_where('perkemb_images', array('perkemb_id' => $perkemb_id))->row();
		if (count($image) != 0) {
			return $image->perkemb_images_id;
		} else {
			return false;
		}
	}

	public function getPerkembReview($perkemb_id) {
		return $this->db
		->join('user_table ut', 'ut.user_id=rt.user_id')
		->get_where('review_table rt', array('perkemb_id' => $perkemb_id))->result();
	}

	public function getPerkembCount() {
		return $this->db->count_all('perkemb_table');
	}

 	public function getLimitPerkemb($limit, $start) {
		$query = $this->db->limit($limit, $start)
			->join('perkemb_images pri', 'pri.perkemb_id = pr.perkemb_id')
			->get_where('perkemb_table pr', array('pr.activeflag' => 0));
		if($query->num_rows() > 0) {
			 return $query->result();
		} else {
			 return false;
		}
	 }
}
?>